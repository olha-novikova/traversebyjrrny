<div class="error wpjm-updater-licence-key-error <?php if ( did_action( 'all_admin_notices' ) ) echo 'inline'; ?>">
	<p><?php echo wp_kses_post( $error ); ?></p>
</div>
