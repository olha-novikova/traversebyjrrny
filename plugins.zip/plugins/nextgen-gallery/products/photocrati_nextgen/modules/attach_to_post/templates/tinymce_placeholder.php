<script type="text/underscore-template" id="ngg-igw-placeholder">
    <div class="mceItem mceNonEditable nggPlaceholder" id="<%- ref %>" data-shortcode="<%- shortcode %>" data-mce-resize="false" data-mce-placeholder="1" contenteditable="false">
        <h3><%- nextgen_gallery %></h3>
        <span title="<%- edit %>" class="nggPlaceholderButton nggIgwEdit">
            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;
        </span>
        <span title="<%- remove %>" class="nggPlaceholderButton nggIgwRemove">
            <i class="fa fa-times-circle" aria-hidden="true"></i>&nbsp;
        </span>
    </div>
</script>