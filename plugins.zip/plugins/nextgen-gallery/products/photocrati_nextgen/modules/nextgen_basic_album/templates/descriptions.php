<?php if (!empty($description)) { ?>
    <p><?php echo $description; ?></p>
<?php } ?>