<span class="field gallery_title_field">
	<input
		type="text"
		name="title"
		id="gallery_title"
		value="<?php echo esc_attr($gallery->title) ?>"
		/>
</span>